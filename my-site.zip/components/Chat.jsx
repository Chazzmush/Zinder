// Placeholder Chat component
export default function Chat() {
  return <div>Chat component will go here.</div>;
}