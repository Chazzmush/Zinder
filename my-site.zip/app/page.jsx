import Chat from "../components/Chat";
import "../styles/globals.css";

export default function Home() {
  return (
    <main>
      <Chat />
    </main>
  );
}